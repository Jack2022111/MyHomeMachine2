This is a group collaboration Senior Project for the Florida Instutite of Technology 2024 Fall Senior Design course. We plan to create a fully functional smart home system.
www.myhomemachine.com
